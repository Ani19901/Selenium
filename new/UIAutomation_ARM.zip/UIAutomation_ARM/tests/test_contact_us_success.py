
def check_success_msg(loc):
    
    msg = helpers.find(loc, 'text')
    return msg


#need to recreate from the scratch
