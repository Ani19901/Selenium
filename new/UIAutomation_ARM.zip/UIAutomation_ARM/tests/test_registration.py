from lib import helpers
from lib import driver
from testdata import test_data
from pages import sign_up


def test_registration():
    helpers.go_to_page(test_data.automationpractice_url)
    sign_up.fill_register_data()
    driver.close_driver()


if __name__ == '__main__':
    test_registration()

# need to finalized test case, SigIn button click function call  is absent
# check registration is success
