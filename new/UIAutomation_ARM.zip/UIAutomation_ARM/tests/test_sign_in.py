from selenium.webdriver.common.by import By
from lib import helpers
from lib import driver
from pages import sign_in
from testdata import test_data


def test():
    sign_in.sign_in()

if __name__ == '__main__':
    test()

# no need use try except in test, move to functions
# Need to check that you are signed in

# 

