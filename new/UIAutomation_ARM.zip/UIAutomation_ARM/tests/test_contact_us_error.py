from lib import helpers, test_logger, driver
from pages import contact_us, home, sign_in, sign_up
from testdata import test_data


def contact_us_error():
    helpers.go_to_page(test_data.login_page)
    sign_in.sign_in()
    helpers.find_and_click(contact_us.btn_contact_us)
    helpers.find_and_click(contact_us.btn_submit)
    assert (test_data.error_message, 'Success')


# no need yry except
# assertion part is not full, error message need to log
