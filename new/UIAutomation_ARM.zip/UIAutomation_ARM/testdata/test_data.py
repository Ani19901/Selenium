import random
import string

email = ''.join([random.choice(string.ascii_lowercase) for _ in range(10)]) + '@yopmail.com'
url = 'http://automationpractice.com/index.php'
first_name = "Volo"
last_name = "Automation"
password = "Qwerty1234"
address_first_name = "Test"
address_last_name = "Automation"
address = "Lorrie drive"
zip_code = "77025"
city = "houston"
state = "Texas"
country = "United States"
mobile_phone = "5127678889"
subject_heading = "customer service"
msg_contactus = "Hello, Thank you for your help"
login_page = 'http://automationpractice.com/index.php?controller=authentication&back=my-account'
error_message = "The message cannot be blank."
