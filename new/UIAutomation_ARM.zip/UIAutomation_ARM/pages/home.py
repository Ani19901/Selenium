from lib import helpers, test_logger, driver
from selenium.webdriver.common.by import By



###########LOCATORS############

dress_name = (By.XPATH, '//*[@id="center_column"]/ul/li')
dress_price = (By.XPATH, '//*[@id="center_column"]/ul/li/div/div[2]/div[1]/span[1]')
btn_login_sign_in = (By.XPATH, "//a[contains(text(),'Sign in')]")


def find_elements_titles_prices():
    titles = helpers.get_text_of_elements(dress_name)
    prices = helpers.get_text_of_elements(dress_price)
    products = helpers.create_dict_from_list(titles, prices)
    helpers.write_in_file(f"This is product: {products}")
